Chaos Installation
==================

Installation
------------
Chaos requires boost and zmq to work. To build and install, just run:

    $ make
    $ make install

The default installation prefix is `/usr/local`. You can change this to prefix PREFIX by running:

    $ make install prefix=PREFIX
