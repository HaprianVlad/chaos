#!/usr/bin/env sh

clush -w @dco_rack[1-3] -l lbindsch "cp -R /media/ssd/hpgp-results ~/."
clush -w @dco_rack[1-3] -l lbindsch "cp -R /media/ssd/hpgp-results ~/."

