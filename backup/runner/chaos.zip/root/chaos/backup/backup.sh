#!/usr/bin/env sh

cp -r helpers/ chaos/backup/
cp -r toolbox/ chaos/backup/
cp -r runner/ chaos/backup/
cp *.sh chaos/backup/
