#!/usr/bin/env sh

TARGET="dco-node[137-144]"

clush -w $TARGET rm -f /media/ssd/stream*
clush -w $TARGET rm -f /media/ssd/core*
clush -w $TARGET rm -f /media/ssd/graph*
clush -w $TARGET rm -f /media/ssd/rmat*







