#!/usr/bin/env sh

TARGET="dco-node[137-144]"
clush -w $TARGET "~/helpers/killall.sh"
sleep 30

