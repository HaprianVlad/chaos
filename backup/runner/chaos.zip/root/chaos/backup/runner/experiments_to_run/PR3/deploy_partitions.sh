#!/usr/bin/env sh

command=~/runner/deploy_partitioning_files.sh
sh $command 28 8 1 ~/runner/experiments_to_run/PR3/partitionFile
