#!/usr/bin/env sh

command=~/runner/deploy_partitioning_files.sh
sh $command 28 8 0 ~/runner/experiments_to_run/BFS4/partitionFile
